document.addEventListener("DOMContentLoaded", function() {
    let dynamicBranchLevels = {};
    const classData = { 
        'Nursery': [{code: 'N1', name: 'Baby Class'}, {code: 'N2', name: 'Middle Class'}, {code: 'N3', name: 'Top Class'}], 
        'Primary': ['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7'].map(c => ({code: c, name: c})), 
        'Secondary': ['S1', 'S2', 'S3', 'S4', 'S5', 'S6'].map(c => ({code: c, name: c})) 
    };

    // Smart pathing: uses .php extension only if running on localhost
    const isLocal = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
    
    const API_URL = '../controllers/ApplicationController.php';

    // 1. Fetch Branches
    const fd = new FormData(); fd.append('action', 'fetch_branches');
    fetch(API_URL, { method: 'POST', body: fd }).then(r => r.json()).then(d => {
        if (d.success) {
            const bs = document.getElementById('branchSelect'); bs.innerHTML = '<option value="">Select School...</option>';
            d.data.forEach(b => {
                bs.innerHTML += `<option value="${b.branch_id}">${b.branch_name}</option>`;
                dynamicBranchLevels[b.branch_id] = b.branch_type ? b.branch_type.split('/').map(l => l.trim()) : ['Nursery', 'Primary', 'Secondary'];
            });
        }
    });

    // 2. Form Logic
    document.getElementById('branchSelect').addEventListener('change', function() {
        const ls = document.getElementById('levelSelect'); ls.innerHTML = '<option value="">Select Level...</option>';
        if (this.value && dynamicBranchLevels[this.value]) dynamicBranchLevels[this.value].forEach(l => ls.innerHTML += `<option value="${l.charAt(0).toUpperCase() + l.slice(1)}">${l}</option>`);
        ls.dispatchEvent(new Event('change'));
    });

    document.getElementById('levelSelect').addEventListener('change', function() {
        const cs = document.getElementById('classSelect'); cs.innerHTML = '<option value="">Select Class...</option>';
        if (this.value && classData[this.value]) classData[this.value].forEach(c => cs.innerHTML += `<option value="${c.code}|${c.name}">${c.name}</option>`);
        document.getElementById('subjectsContainer').style.display = 'none'; document.getElementById('examContainer').style.display = 'none';
    });

    // 3. Smart Academic History Logic
    document.getElementById('classSelect').addEventListener('change', function() {
    const cv = this.value.split('|')[0]; 
    const ex = document.getElementById('examContainer'); 
    const subCont = document.getElementById('subjectsContainer');
    const addSubBtn = document.getElementById('addSubjectBtn');
    
    ex.innerHTML = ''; 
    ex.style.display = 'block';

    // Logic for S1 (PLE Specifics + Dual Option)
    if (cv === 'S1') {
        ex.innerHTML = `
            <h4 style="color:var(--primary-color);">Primary Leaving Examinations (PLE) Details</h4>
            <div class="form-grid" style="margin-bottom: 15px;">
                <div class="form-group"><label>PLE Index Number</label><input class="app-input" type="text" name="ple_ref" required></div>
                <div class="form-group"><label>Aggregate Score</label><input class="app-input" type="number" name="ple_score" required></div>
            </div>
            <h4 style="color:var(--primary-color);">Academic Record</h4>
            <div class="form-group" style="margin-bottom: 20px;">
                <label> Upload PLE Pass Slip (PDF/Image)</label>
                <input class="app-input" type="file" name="prev_marks_doc" accept="application/pdf, image/jpeg, image/png">
            </div>
        `;
        subCont.style.display = 'block';
        addSubBtn.style.display = 'inline-block';
    } 
    // Logic for S5 (UCE Specifics + Dual Option)
    else if (cv === 'S5') {
        ex.innerHTML = `
            <h4 style="color:var(--primary-color);">Uganda Certificate of Education (UCE) Details</h4>
            <div class="form-grid">
                <div class="form-group"><label>UCE Index Number</label><input class="app-input" type="text" name="uce_ref"></div>
                <div class="form-group"><label>Aggregate Score</label><input class="app-input" type="number" name="uce_score"></div>
            </div>
            <div class="form-group" style="margin-top: 20px;">
                <label> Upload UCE Results Slip</label>
                <<input class="app-input" type="file" name="prev_marks_doc" accept="application/pdf, image/jpeg, image/png">
        `;
        subCont.style.display = 'block';
        addSubBtn.style.display = 'inline-block';
    } 
    // Logic for all other classes (P1-P7, S2-S4, S6)
    else {
        ex.innerHTML = `
            <h4 style="color:var(--primary-color);">Previous Academic Record</h4>
            <div class="form-group" style="margin-bottom: 20px;">
                <label> Upload Previous School Report Card (PDF/Image)</label>
                <input class="app-input" type="file" name="prev_marks_doc" accept="application/pdf, image/jpeg, image/png">
        `;
        subCont.style.display = 'block';
        addSubBtn.style.display = 'inline-block';
    }
});

    document.getElementById('addSubjectBtn').addEventListener('click', () => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td><input class="app-input" type="text" name="subject_name[]" placeholder="Subject Name"></td>
        <td><input class="app-input" type="number" name="subject_mark[]" placeholder="Marks" max="100"></td>
        <td><input class="app-input" type="text" name="subject_grade[]" placeholder="Grade"></td>
        <td style="text-align:center;">
            <button type="button" class="btn-remove" onclick="this.closest('tr').remove()">X</button>
        </td>`;
    document.getElementById('subjectsBody').appendChild(tr);
});

    // 4. Photo Validation (Max 50KB)
    document.querySelector('input[name="photo"]').addEventListener('change', function() {
        if (this.files[0] && (this.files[0].size / 1024) > 50) {
            Swal.fire('File Too Large', 'Maximum photo size is 50KB.', 'error');
            this.value = '';
        }
    });
    // 5. Submit Form
    document.getElementById('publicAppForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const submitBtn = document.getElementById('submitBtn');
        submitBtn.innerHTML = 'Processing Application...'; 
        submitBtn.disabled = true;

        fetch(API_URL, { method: 'POST', body: new FormData(this) })
        .then(r => r.json())
        .then(d => {
            if(d.success) { 
                document.getElementById('publicAppForm').style.display = 'none'; 
                
                // SweetAlert Updated: Made "Download PDF" the primary confirmed action
                Swal.fire({ 
                    title: 'Application Successful!', 
                    html: `<p style="font-size: 16px;">Your Official Reference Number is: <br><strong style="color: #28a745; font-size: 22px;">${d.ref_number}</strong></p><p>Please download your application copy below.</p>`, 
                    icon: 'success', 
                    showCancelButton: true, 
                    confirmButtonText: 'Download Application PDF', 
                    cancelButtonText: 'Finish & Close',
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#6c757d',
                    allowOutsideClick: false
                }).then((result) => { 
                    // Now triggers correctly when the user explicitly hits Download
                    if (result.isConfirmed) { 
                        generatePDFReceipt(d.ref_number); 
                    } 
                });
            } else {
                Swal.fire('Error', d.message, 'error');
                submitBtn.innerHTML = 'Submit Application form'; 
                submitBtn.disabled = false;
            }
        });
    });

    // 6. Comprehensive PDF Generator
    function generatePDFReceipt(refNumber) {
        if (!window.jspdf) {
            Swal.fire('Error', 'PDF engine not loaded. Please ensure jspdf.umd.min.js is in your scripts folder.', 'error');
            return;
        }

        const { jsPDF } = window.jspdf; 
        const doc = new jsPDF();
        
        let yPos = 20;
        const leftMargin = 15;
        const valueMargin = 65;
        const lineHeight = 7;
        
        // --- Header ---
        doc.setFontSize(16);
        doc.setFont("helvetica", "bold");
        doc.setTextColor(41, 128, 185);
        doc.text("Montfort Brothers of St. Gabriel: Uganda", 105, yPos, null, null, "center");
        yPos += 8;
        doc.setFontSize(14);
        doc.setTextColor(0, 0, 0);
        doc.text("Official Admission Application Document", 105, yPos, null, null, "center");
        yPos += 12;
        
        // Helper function for professional section headers
        function addSection(title) {
            if (yPos > 275) { doc.addPage(); yPos = 20; }
            yPos += 4;
            doc.setFontSize(11);
            doc.setFont("helvetica", "bold");
            doc.setTextColor(255, 255, 255);
            doc.setFillColor(41, 128, 185); // Blue background for headers
            doc.rect(leftMargin, yPos - 5, 180, 7, 'F');
            doc.text(title, leftMargin + 2, yPos);
            doc.setTextColor(0, 0, 0); 
            yPos += 8;
        }
        
        // Helper function for data rows
        function addRow(label, value) {
            if (yPos > 280) { doc.addPage(); yPos = 20; }
            doc.setFontSize(10);
            doc.setFont("helvetica", "bold");
            doc.text(label + ":", leftMargin, yPos);
            
            doc.setFont("helvetica", "normal");
            const textVal = value && String(value).trim() !== "" ? String(value) : 'N/A';
            const textLines = doc.splitTextToSize(textVal, 190 - valueMargin);
            doc.text(textLines, valueMargin, yPos);
            yPos += (textLines.length * lineHeight);
        }
        
        const form = document.getElementById('publicAppForm');
        
        // Extract dropdown labels
        const branchSelect = document.getElementById('branchSelect');
        const branchName = branchSelect.options[branchSelect.selectedIndex]?.text || 'N/A';
        const classSelect = document.getElementById('classSelect');
        const className = classSelect.options[classSelect.selectedIndex]?.text || 'N/A';
        const levelSelect = document.getElementById('levelSelect');
        const levelName = levelSelect.options[levelSelect.selectedIndex]?.text || 'N/A';
        
        // --- 1. Enrollment Details ---
        addSection("1. Enrollment Details");
        addRow("Reference No.", refNumber);
        addRow("School Branch", branchName);
        addRow("Level & Class", `${levelName} - ${className}`);
        addRow("Admission Year", form.querySelector('[name="admission_year"]')?.value);
        addRow("Term", form.querySelector('[name="term"]')?.value);
        addRow("Reg. Date", form.querySelector('[name="reg_date"]')?.value);
        
        // --- 2. Student Details ---
        addSection("2. Student Details");
        const fullName = `${form.querySelector('[name="name"]')?.value || ''} ${form.querySelector('[name="middle_name"]')?.value || ''} ${form.querySelector('[name="surname"]')?.value || ''}`.trim();
        addRow("Full Name", fullName);
        addRow("Gender", form.querySelector('[name="gender"]')?.value);
        addRow("Date of Birth", form.querySelector('[name="dob"]')?.value);
        addRow("Nationality", form.querySelector('[name="nationality"]')?.value);
        
        // --- 3. Contact & Address ---
        addSection("3. Contact & Address");
        addRow("Physical Address", `${form.querySelector('[name="house"]')?.value || ''}, ${form.querySelector('[name="street"]')?.value || ''}`);
        addRow("Village / Town", form.querySelector('[name="village"]')?.value);
        addRow("District", form.querySelector('[name="district"]')?.value);
        addRow("Postal Code", form.querySelector('[name="postal"]')?.value);
        
        // --- 4. Family Details ---
        addSection("4. Family Details");
        addRow("Father", `${form.querySelector('[name="f_name"]')?.value || 'N/A'} | Contact: ${form.querySelector('[name="f_con"]')?.value || 'N/A'} | Occ: ${form.querySelector('[name="f_occ"]')?.value || 'N/A'}`);
        addRow("Mother", `${form.querySelector('[name="m_name"]')?.value || 'N/A'} | Contact: ${form.querySelector('[name="m_con"]')?.value || 'N/A'} | Occ: ${form.querySelector('[name="m_occ"]')?.value || 'N/A'}`);
        
        // Include Guardian if filled out
        const gName = form.querySelector('[name="g_name"]')?.value;
        if(gName && gName.trim() !== "") {
            addRow("Guardian", `${gName} (${form.querySelector('[name="g_rel"]')?.value || ''}) | Contact: ${form.querySelector('[name="g_con"]')?.value || 'N/A'}`);
        }

        // --- 5. Academic Background ---
        addSection("5. Academic Background");
        addRow("Former School", form.querySelector('[name="former_school"]')?.value);
        addRow("Former School LIN", form.querySelector('[name="former_school_lin"]')?.value);
        
        // Dynamic Exam Info (PLE / UCE)
        const pleRef = form.querySelector('[name="ple_ref"]')?.value;
        if(pleRef) addRow("PLE Index / Score", `${pleRef} / ${form.querySelector('[name="ple_score"]')?.value || 'N/A'}`);
        
        const uceRef = form.querySelector('[name="uce_ref"]')?.value;
        if(uceRef) addRow("UCE Index / Score", `${uceRef} / ${form.querySelector('[name="uce_score"]')?.value || 'N/A'}`);

        // Extract Dynamic Subjects (Loops through the table rows)
        const subjectNames = document.getElementsByName('subject_name[]');
        const subjectMarks = document.getElementsByName('subject_mark[]');
        const subjectGrades = document.getElementsByName('subject_grade[]');
        
        if (subjectNames.length > 0 && subjectNames[0].value !== "") {
            addSection("Submitted Subjects & Marks");
            for (let i = 0; i < subjectNames.length; i++) {
                if (subjectNames[i].value) {
                    let subDetails = [];
                    if (subjectMarks[i] && subjectMarks[i].value) subDetails.push(`Marks: ${subjectMarks[i].value}`);
                    if (subjectGrades[i] && subjectGrades[i].value) subDetails.push(`Grade: ${subjectGrades[i].value}`);
                    addRow(subjectNames[i].value, subDetails.join(' | ') || 'N/A');
                }
            }
        }

        // --- 6. Additional Info ---
        addSection("6. Additional Information");
        addRow("Medical Info", form.querySelector('[name="more_info"]')?.value || "None specified");
        
        // --- Footer ---
        yPos += 15;
        if (yPos > 280) { doc.addPage(); yPos = 20; }
        doc.setFontSize(9);
        doc.setFont("helvetica", "italic");
        doc.setTextColor(150, 150, 150);
        doc.text("Generated by Montfort School Admission Portal. Please keep this copy safe.", 105, yPos, null, null, "center");
        
        // Trigger Download
        doc.save(`${refNumber}_Application.pdf`);
    }
});