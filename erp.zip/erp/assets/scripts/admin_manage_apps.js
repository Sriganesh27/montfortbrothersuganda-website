function loadApplications() {
    const status = document.getElementById('statusFilter').value;
    fetch(`controllers/AdminAppController.php?action=fetch_list&status=${status}`)
    .then(r => r.json())
    .then(d => {
        let html = '';
        d.data.forEach(app => {
            // NEW: Always show the Review Button
            let actions = `<button class="btn-action" style="background:#17a2b8;" onclick="viewApplication(${app.app_id})">Review</button> `;
            
            if (app.status === 'Pending') {
                actions += `<button class="btn-action btn-shortlist" onclick="updateAppStatus(${app.app_id}, 'Shortlisted')">Shortlist</button>`;
            } else if (app.status === 'Shortlisted') {
                actions += `<button class="btn-action btn-select" onclick="updateAppStatus(${app.app_id}, 'Selected')">Select</button>`;
            } else if (app.status === 'Selected') {
                // FIXED: Changed loadModule to standard hash navigation for your ERP
                actions += `<button class="btn-action btn-admit" onclick="window.location.href='admin?prefill_app_id=${app.app_id}#admission'">Admit</button>`;
            }

            const sNone = app.scholarship_status === 'None' ? 'selected' : '';
            const sApp = app.scholarship_status === 'Applied' ? 'selected' : '';
            const sConf = app.scholarship_status === 'Confirmed' ? 'selected' : '';

            html += `<tr>
                <td>${app.ref_number}</td>
                <td>${app.student_name} ${app.student_surname}</td>
                <td>${app.applied_class}</td>
                <td><strong>${app.status}</strong></td>
                <td>
                    <select class="schol-select" onchange="updateAppScholarship(${app.app_id}, this.value)">
                        <option value="None" ${sNone}>No Aid</option>
                        <option value="Applied" ${sApp}>Applied</option>
                        <option value="Confirmed" ${sConf}>Confirmed</option>
                    </select>
                </td>
                <td>${actions}</td>
            </tr>`;
        });
        document.getElementById('appBody').innerHTML = html;
    });
}

// NEW: Application Review Modal (With Visual Photo Header)
function viewApplication(id) {
    fetch(`controllers/AdminAppController.php?action=fetch_single&app_id=${id}`)
    .then(r => r.json())
    .then(d => {
        if(d.success) {
            const app = d.data;
            const fullName = `${app.student_name || ''} ${app.student_middle_name || app.mname || ''} ${app.student_surname || app.surname || ''}`.trim();
            const address = `${app.house || app.house_no || ''} ${app.street || ''}, ${app.village || ''}, ${app.district || ''}, ${app.state || ''} (PO BOX: ${app.postal || app.postal_code || 'N/A'})`.trim();
            
            // Set the photo source (use a default if none exists)
            const photoSrc = app.photo_path ? app.photo_path : '../../assets/Images/default_profile.png';

            // Build Subject Marks HTML if they exist
            let subjectMarksHtml = '';
            if (app.subject_marks && app.subject_marks !== '[]') {
                try {
                    let marks = JSON.parse(app.subject_marks);
                    subjectMarksHtml = `<div class="grid-item full-width" style="margin-top: 15px; background: #f8fafc; padding: 10px; border-radius: 5px; border: 1px solid #e2e8f0;">
                        <strong>Entered Subjects & Grades</strong>
                        <ul style="margin: 5px 0 0 20px; font-size: 14px; color: #333;">`;
                    marks.forEach(m => {
                        subjectMarksHtml += `<li>${m.subject} &nbsp;&mdash;&nbsp; Mark: <strong>${m.mark || m.grade || '-'}</strong> | Grade: <strong>${m.grade || '-'}</strong></li>`;
                    });
                    subjectMarksHtml += `</ul></div>`;
                } catch(e) {}
            }

            // Construct the HTML Layout
            let html = `
                <div style="display: flex; justify-content: space-between; align-items: center; padding-bottom: 15px; margin-bottom: 15px; border-bottom: 2px solid #eee;">
                    <div>
                        <h3 style="margin:0; font-size: 24px; color: var(--primary-color);">${fullName}</h3>
                        <p style="margin:5px 0; color: #666; font-size: 14px;">Reference: <strong>${app.ref_number || 'N/A'}</strong></p>
                        <span style="background:var(--primary-color); color:white; padding:4px 10px; border-radius:15px; font-size:12px;">${app.applied_level || ''}</span>
                        <span style="background:var(--accent-color); color:white; padding:4px 10px; border-radius:15px; font-size:12px;">${app.applied_class || ''}</span>
                    </div>
                    <div>
                        <img src="${photoSrc}" style="width: 90px; height: 90px; border-radius: 50%; object-fit: cover; border: 3px solid #e2e8f0; box-shadow: 0 4px 6px rgba(0,0,0,0.1);" alt="Student Photo">
                    </div>
                </div>

                <div class="profile-grid-system">
                    
                    <fieldset>
                        <legend>1. Personal Details</legend>
                        <div class="grid-row">
                            <div class="grid-item"><strong>Admission Year</strong> <p>${app.admission_year || app.year || 'N/A'}</p></div>
                            <div class="grid-item"><strong>Gender</strong> <p>${app.gender || 'N/A'}</p></div>
                            <div class="grid-item"><strong>Date of Birth</strong> <p>${app.dob || 'N/A'}</p></div>
                            
                            <div class="grid-item"><strong>Nationality</strong> <p>${app.nationality || 'N/A'}</p></div>
                            <div class="grid-item full-width"><strong>Address</strong> <p>${address}</p></div>
                        </div>
                    </fieldset>

                    <fieldset>
                        <legend>2. Family Details</legend>
                        <div class="grid-row">
                            <div class="grid-item"><strong>Father's Name</strong> <p>${app.father_name || app.f_name || 'N/A'}</p></div>
                            <div class="grid-item"><strong>Father's Contact</strong> <p>${app.father_contact || app.f_con || 'N/A'}</p></div>
                            <div class="grid-item"><strong>Father's Occ.</strong> <p>${app.father_occupation || app.f_occ || 'N/A'}</p></div>
                            
                            <div class="grid-item"><strong>Mother's Name</strong> <p>${app.mother_name || app.m_name || 'N/A'}</p></div>
                            <div class="grid-item"><strong>Mother's Contact</strong> <p>${app.mother_contact || app.m_con || 'N/A'}</p></div>
                            <div class="grid-item"><strong>Mother's Occ.</strong> <p>${app.mother_occupation || app.m_occ || 'N/A'}</p></div>
                            
                            <div class="grid-item"><strong>Guardian Name</strong> <p>${app.guardian_name || app.g_name || 'N/A'} <span style="font-size:12px; color:#888;">(${app.guardian_relation || app.g_rel || 'N/A'})</span></p></div>
                            <div class="grid-item"><strong>Guardian Contact</strong> <p>${app.guardian_contact || app.g_con || 'N/A'}</p></div>
                            <div class="grid-item"><strong>Guardian Occ.</strong> <p>${app.guardian_occupation || app.g_occ || 'N/A'}</p></div>
                        </div>
                    </fieldset>

                    <fieldset>
                        <legend>3. Academic History</legend>
                        <div class="grid-row">
                            <div class="grid-item full-width"><strong>Former School</strong> <p>${app.former_school || 'N/A'} (Code: ${app.former_school_code || 'N/A'} | LIN: ${app.former_school_lin || 'N/A'})</p></div>
                            
                            <div class="grid-item"><strong>PLE Index No</strong> <p>${app.ple_ref || 'N/A'}</p></div>
                            <div class="grid-item"><strong>PLE Score</strong> <p>${app.ple_score || 'N/A'}</p></div>
                            <div class="grid-item"></div>
                            
                            <div class="grid-item"><strong>UCE Index No</strong> <p>${app.uce_ref || 'N/A'}</p></div>
                            <div class="grid-item"><strong>UCE Score</strong> <p>${app.uce_score || 'N/A'}</p></div>
                            <div class="grid-item"></div>
                            
                            ${subjectMarksHtml}
                        </div>
                    </fieldset>

                    <fieldset>
                        <legend>4. Documents & Notes</legend>
                        <div class="grid-row">
                            <div class="grid-item full-width"><strong>Medical / Extra Notes</strong> <p style="color:#d35400;">${app.more_info || 'None provided'}</p></div>
                            <div class="grid-item full-width">
                                <strong>Attached Files</strong> 
                                <div style="display: flex; gap: 10px; margin-top: 8px;">
                                    ${app.prev_marks_doc ? `<a href="${app.prev_marks_doc}" target="_blank" style="padding:8px 15px; background:var(--secondary-color); color:white; text-decoration:none; border-radius:4px; font-weight:600;"><i class="fa fa-file-pdf"></i> View Previous Marks Document</a>` : '<span style="color:#888;">No academic documents uploaded.</span>'}
                                </div>
                            </div>
                        </div>
                    </fieldset>

                </div>
            `;
            
            document.getElementById('appModalBody').innerHTML = html;
            document.getElementById('appReviewModal').style.display = 'flex';
        } else {
            alert(d.message);
        }
    });
}

function updateAppStatus(id, stat) { 
    const fd = new FormData(); 
    fd.append('action', 'update_status'); 
    fd.append('app_id', id); 
    fd.append('status', stat); 
    fetch('controllers/AdminAppController.php', {method: 'POST', body: fd})
    .then(() => loadApplications()); 
}

function updateAppScholarship(id, stat) { 
    const fd = new FormData(); 
    fd.append('action', 'update_scholarship'); 
    fd.append('app_id', id); 
    fd.append('scholarship', stat); 
    fetch('controllers/AdminAppController.php', {method: 'POST', body: fd})
    .then(r => r.json())
    .then(d => alert(d.message)); 
}

if (document.getElementById('statusFilter')) {
    loadApplications();
}