// Append the action for the MVC Controller
        formData.append('action', 'login');

        fetch('controllers/AuthController.php', {
            method: 'POST',
            body: formData
        })