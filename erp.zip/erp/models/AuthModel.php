<?php
// erp/models/AuthModel.php

class AuthModel {
    private $conn;

    public function __construct($db_connection) {
        $this->conn = $db_connection;
    }

    // Fetch user by username
    public function getUserByUsername($username) {
        $stmt = $this->conn->prepare("SELECT user_id, username, password, role, branch_id, is_active FROM erp_users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        return $result;
    }

    // Fetch branch details by branch ID
    public function getBranchDetails($branch_id) {
        $stmt = $this->conn->prepare("SELECT branch_name, status FROM erp_branches WHERE branch_id = ?");
        $stmt->bind_param("i", $branch_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        return $result;
    }

    // Update last login timestamp
    public function updateLastLogin($user_id) {
        $stmt = $this->conn->prepare("UPDATE erp_users SET last_login = NOW() WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();
    }
}
?>