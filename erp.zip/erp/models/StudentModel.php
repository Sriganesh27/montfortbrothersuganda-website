<?php
// erp/models/StudentModel.php

class StudentModel {
    private $conn;

    public function __construct($db_connection) {
        $this->conn = $db_connection;
    }

    // Completely handles the database transaction for admitting a student
    public function admitStudent($branch_id, $ad_no, $data, $hashed_password, $final_username) {
        $this->conn->begin_transaction();

        try {
            // 1. Insert Student
            $sql_stu = "INSERT INTO erp_students (AdmissionNo, branch_id, AdmissionYear, Name, MiddleName, Surname, DateOfBirth, Gender, Nationality, HouseNo, Street, Village, Town, District, State, Country, PostalCode) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt_stu = $this->conn->prepare($sql_stu);
            $stmt_stu->bind_param("iiissssssssssssss", 
                $ad_no, $branch_id, $data['admission_year'], $data['name'], $data['middle_name'], 
                $data['surname'], $data['dob'], $data['gender'], $data['nationality'], 
                $data['house_no'], $data['street'], $data['village'], $data['town'], 
                $data['district'], $data['state'], $data['country'], $data['postal_code']
            );
            $stmt_stu->execute();
            $stmt_stu->close();

            // 2. Insert Parents
            $sql_par = "INSERT INTO erp_parents (AdmissionNo, branch_id, father_name, father_contact, father_email, father_age, father_occupation, father_education, mother_name, mother_contact, mother_email, mother_age, mother_occupation, mother_education, guardian_name, guardian_relation, guardian_contact, guardian_email, guardian_age, guardian_occupation, guardian_education, guardian_address, MoreInformation) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt_par = $this->conn->prepare($sql_par);
            $stmt_par->bind_param("iisssisssssissssssissss", 
                $ad_no, $branch_id, $data['father_name'], $data['father_contact'], $data['father_email'], 
                $data['father_age'], $data['father_occupation'], $data['father_education'], 
                $data['mother_name'], $data['mother_contact'], $data['mother_email'], 
                $data['mother_age'], $data['mother_occupation'], $data['mother_education'], 
                $data['guardian_name'], $data['guardian_relation'], $data['guardian_contact'], 
                $data['guardian_email'], $data['guardian_age'], $data['guardian_occupation'], 
                $data['guardian_education'], $data['guardian_address'], $data['more_info']
            );
            $stmt_par->execute();
            $stmt_par->close();

            // 3. Insert Academic History
            $sql_hist = "INSERT INTO erp_academichistory (AdmissionNo, branch_id, FormerSchool, FormerSchoolCode, FormerSchoolLIN, PLEIndexNumber, PLEAggregate, UCEIndexNumber, UCEResult, SubjectMarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt_hist = $this->conn->prepare($sql_hist);
            $stmt_hist->bind_param("iisssssiss", 
                $ad_no, $branch_id, $data['former_school'], $data['former_school_code'], 
                $data['former_school_lin'], $data['ple_index'], $data['ple_agg'], 
                $data['uce_index'], $data['uce_result'], $data['subject_marks']
            );
            $stmt_hist->execute();
            $stmt_hist->close();

            // 4. Insert Enrollment
            $sql_enr = "INSERT INTO erp_enrollment (AdmissionNo, branch_id, AcademicYear, Term, Class, Level, Stream, Residence, EntryStatus) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt_enr = $this->conn->prepare($sql_enr);
            $stmt_enr->bind_param("iisssssss", 
                $ad_no, $branch_id, $data['academic_year'], $data['term'], $data['class'], 
                $data['level'], $data['stream'], $data['residence'], $data['entry_status']
            );
            $stmt_enr->execute();
            $stmt_enr->close();

            // 5. Insert Student Account
            $is_active = 1;
            $sql_acc = "INSERT INTO erp_student_accounts(AdmissionNo, branch_id, username, password, is_active) VALUES (?, ?, ?, ?, ?)";
            $stmt_acc = $this->conn->prepare($sql_acc);
            $stmt_acc->bind_param("iissi", $ad_no, $branch_id, $final_username, $hashed_password, $is_active);
            $stmt_acc->execute();
            $stmt_acc->close();

            // 6. Close Application Loop (If coming from the admission portal)
            if (!empty($data['link_app_id'])) {
                $stmt_app = $this->conn->prepare("UPDATE erp_applications SET status = 'Admitted' WHERE app_id = ? AND branch_id = ?");
                $stmt_app->bind_param("ii", $data['link_app_id'], $branch_id);
                $stmt_app->execute();
                $stmt_app->close();
            }

            $this->conn->commit();
            return true;

        } catch (Exception $e) {
            $this->conn->rollback();
            throw $e;
        }
    }

    // Updates the photo path in the database after successful file upload
    public function updatePhotoPath($ad_no, $branch_id, $photo_path) {
        $stmt = $this->conn->prepare("UPDATE erp_students SET PhotoPath = ? WHERE AdmissionNo = ? AND branch_id = ?");
        $stmt->bind_param("sii", $photo_path, $ad_no, $branch_id);
        $stmt->execute();
        $stmt->close();
    }
}
?>