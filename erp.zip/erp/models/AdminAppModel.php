<?php
// models/AdminAppModel.php

class AdminAppModel {
    private $conn;

    public function __construct($db_connection) {
        $this->conn = $db_connection;
    }

    public function fetchList($branch_id, $status) {
        $sql = "SELECT app_id, ref_number, student_name, student_surname, applied_class, status, scholarship_status, created_at FROM erp_applications WHERE branch_id = ?";
        $params = [$branch_id]; 
        $types = "i";
        
        if ($status !== 'All') { 
            $sql .= " AND status = ?"; 
            $params[] = $status; 
            $types .= "s"; 
        }
        $sql .= " ORDER BY created_at DESC";

        $stmt = $this->conn->prepare($sql); 
        $stmt->bind_param($types, ...$params); 
        $stmt->execute();
        $res = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $res;
    }

    public function fetchSingle($branch_id, $app_id) {
        $stmt = $this->conn->prepare("SELECT * FROM erp_applications WHERE app_id = ? AND branch_id = ?");
        $stmt->bind_param("ii", $app_id, $branch_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $result;
    }

    public function updateStatus($branch_id, $app_id, $status) {
        $stmt = $this->conn->prepare("UPDATE erp_applications SET status = ? WHERE app_id = ? AND branch_id = ?");
        $stmt->bind_param("sii", $status, $app_id, $branch_id);
        $res = $stmt->execute();
        $stmt->close();
        return $res;
    }

    public function updateScholarship($branch_id, $app_id, $scholarship) {
        $stmt = $this->conn->prepare("UPDATE erp_applications SET scholarship_status = ? WHERE app_id = ? AND branch_id = ?");
        $stmt->bind_param("sii", $scholarship, $app_id, $branch_id);
        $res = $stmt->execute();
        $stmt->close();
        return $res;
    }
}
?>