<?php
// models/SchoolModel.php
class SchoolModel {
    private $conn;

    public function __construct($db_connection) {
        $this->conn = $db_connection;
    }

    public function getAllBranches() {
        return $this->conn->query("SELECT * FROM erp_branches ORDER BY branch_id DESC")->fetch_all(MYSQLI_ASSOC);
    }

    public function saveBranch($id, $name, $loc, $type) {
        if ($id) {
            $stmt = $this->conn->prepare("UPDATE erp_branches SET branch_name=?, branch_location=?, branch_type=? WHERE branch_id=?");
            $stmt->bind_param("sssi", $name, $loc, $type, $id);
        } else {
            $stmt = $this->conn->prepare("INSERT INTO erp_branches (branch_name, branch_location, branch_type) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $name, $loc, $type);
        }
        return $stmt->execute();
    }

    public function getStudentCount($branch_id) {
        $stmt = $this->conn->prepare("SELECT COUNT(*) as total FROM erp_students WHERE branch_id = ?");
        $stmt->bind_param("i", $branch_id);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc()['total'];
    }

    public function deleteBranch($id) {
        $stmt = $this->conn->prepare("DELETE FROM erp_branches WHERE branch_id = ?");
        $stmt->bind_param("i", $id);
        return $stmt->execute();
    }
}