<?php
// erp/index.php
session_start();

if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    $role = $_SESSION['role'];
    if ($role === 'Super User') header("Location: super_admin"); // Removed .php
    elseif ($role === 'Branch Admin') header("Location: admin"); // Removed .php
    else header("Location: login"); // Removed .php
    exit;
}

require_once 'login.php'; // Backend requires keep the .php
?>