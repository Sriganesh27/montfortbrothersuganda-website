<div id="schools-module" class="module" style="display: none;">
    <div class="super-header">
        <h1>Institutional Management</h1>
        <button onclick="openBranchModal()">Add New School</button>
    </div>

    <table class="branch-table">
        <thead>
            <tr><th>Branch Name</th><th>Location</th><th>Actions</th></tr>
        </thead>
        <tbody id="branch-list-results"></tbody>
    </table>
</div>

<script>
// This JavaScript handles the 'View' behavior
function loadBranches() {
    // Calling the clean URL route (defined in your .htaccess)
    fetch('controllers/SchoolController?action=list')
    .then(r => r.json())
    .then(data => {
        const tbody = document.getElementById('branch-list-results');
        tbody.innerHTML = data.map(b => `
            <tr>
                <td>${b.branch_name}</td>
                <td>${b.branch_location}</td>
                <td><button onclick="deleteBranch(${b.branch_id})">Delete</button></td>
            </tr>
        `).join('');
    });
}
loadBranches();
</script>