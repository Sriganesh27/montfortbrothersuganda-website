<?php
// erp/controllers/StudentController.php

session_start();
header('Content-Type: application/json');

require_once '../config/config.php';
require_once '../includes/db.php'; // Needed for get_next_admission_no()
require_once '../models/StudentModel.php';

global $DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, $UPLOAD_DIR_BASE, $UPLOAD_FOLDER_REL;
$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}

$branch_id = $_SESSION['branch_id'] ?? null;
if (!$branch_id) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized: No school branch identified.']);
    exit;
}

$action = $_POST['action'] ?? '';
$studentModel = new StudentModel($conn);

if ($action === 'admit_student') {
    try {
        // 1. Sanitize & Package Data Array
        $data = [
            'name' => trim($_POST['name'] ?? ''),
            'middle_name' => trim($_POST['middle_name'] ?? ''),
            'surname' => trim($_POST['surname'] ?? ''),
            'dob' => $_POST['dob'] ?? null,
            'gender' => $_POST['gender'] ?? '',
            'nationality' => trim($_POST['nationality'] ?? 'Ugandan'),
            
            'postal_code' => trim($_POST['postal_code'] ?? ''),
            'house_no' => trim($_POST['house_no'] ?? ''),
            'street' => trim($_POST['street'] ?? ''),
            'village' => trim($_POST['village'] ?? ''),
            'town' => trim($_POST['town'] ?? ''),
            'district' => trim($_POST['district'] ?? ''),
            'state' => trim($_POST['state'] ?? ''),
            'country' => trim($_POST['country'] ?? 'Uganda'),

            'father_name' => trim($_POST['father_name'] ?? ''),
            'father_contact' => trim($_POST['father_contact'] ?? null),
            'father_occupation' => trim($_POST['father_occupation'] ?? ''),
            'father_email' => trim($_POST['father_email'] ?? null),
            'father_age' => $_POST['father_age'] ?? null,
            'father_education' => $_POST['father_education'] ?? '',

            'mother_name' => trim($_POST['mother_name'] ?? ''),
            'mother_contact' => trim($_POST['mother_contact'] ?? null),
            'mother_occupation' => trim($_POST['mother_occupation'] ?? ''),
            'mother_email' => trim($_POST['mother_email'] ?? null),
            'mother_age' => $_POST['mother_age'] ?? null,
            'mother_education' => $_POST['mother_education'] ?? '',

            'guardian_name' => trim($_POST['guardian_name'] ?? null),
            'guardian_relation' => trim($_POST['guardian_relation'] ?? null),
            'guardian_contact' => trim($_POST['guardian_contact'] ?? null),
            'guardian_address' => trim($_POST['guardian_address'] ?? null),
            'guardian_email' => null, 'guardian_age' => null, 'guardian_occupation' => null, 'guardian_education' => null,

            'admission_year' => $_POST['admission_year'] ?? date('Y'),
            'academic_year' => format_academic_year($_POST['admission_year'] ?? date('Y')),
            'term' => $_POST['term'] ?? '',
            'level' => $_POST['level'] ?? '',
            'class' => str_replace([' ', '.', 'PP'], ['', '', 'N'], strtoupper($_POST['class'] ?? '')),
            'stream' => $_POST['stream'] ?? 'A',
            'residence' => $_POST['residence'] ?? 'Day',
            'entry_status' => $_POST['entry_status'] ?? 'New',

            'former_school' => trim($_POST['former_school'] ?? ''),
            'former_school_code' => trim($_POST['former_school_code'] ?? ''),
            'former_school_lin' => trim($_POST['former_school_lin'] ?? ''),
            'ple_index' => trim($_POST['ple_index'] ?? ''),
            'ple_agg' => !empty($_POST['ple_agg']) ? $_POST['ple_agg'] : null,
            'uce_index' => trim($_POST['uce_index'] ?? ''),
            'uce_result' => trim($_POST['uce_result'] ?? ''),
            'subject_marks' => trim($_POST['subject_marks'] ?? ''),

            'more_info' => trim($_POST['more_info'] ?? ''),
            'link_app_id' => !empty($_POST['link_app_id']) ? (int)$_POST['link_app_id'] : null
        ];

        // 2. Validate essential fields
        if (empty($data['name']) || empty($data['surname']) || empty($data['class'])) {
            throw new Exception("Missing required fields: Name, Surname, or Class.");
        }

        // 3. Generate IDs and Passwords
        $ad_no = get_next_admission_no($conn, $branch_id);
        $hashed_password = password_hash($data['surname'] . $data['admission_year'], PASSWORD_DEFAULT);
        
        $year_short = substr((string)$data['admission_year'], -2);
        $formatted_ad_no = str_pad((string)$ad_no, 4, '0', STR_PAD_LEFT);
        
        // Fetch branch code for Student ID (Default to U011 if missing)
        $stmt_code = $conn->prepare("SELECT school_code, branch_name, branch_location FROM erp_branches WHERE branch_id = ?");
        $stmt_code->bind_param("i", $branch_id);
        $stmt_code->execute();
        $branch_data = $stmt_code->get_result()->fetch_assoc();
        $school_code = $branch_data['school_code'] ?? 'U011';
        $stmt_code->close();

        $final_username = $school_code . "-" . $year_short . "-" . $data['class'] . "-" . $formatted_ad_no;

        // 4. Pass to Model to execute Database transaction
        if ($studentModel->admitStudent($branch_id, $ad_no, $data, $hashed_password, $final_username)) {
            
            // 5. Handle Photo Upload securely
            if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['photo'];
                if ($file['size'] <= 1048576) { // 1MB Limit
                    $UPLOAD_DIR = dirname(rtrim($UPLOAD_DIR_BASE, '/')) . '/'; 
                    $REAL_UPLOAD_REL = dirname(rtrim($UPLOAD_FOLDER_REL, '/')) . '/';
                    
                    $safe_branch = sanitize_for_filename($branch_data['branch_name'] ?? 'School');
                    $safe_location = sanitize_for_filename($branch_data['branch_location'] ?? 'Location');
                    $safe_student = sanitize_for_filename($data['name'] . '_' . $data['surname']);
                    
                    $custom_folder = $safe_branch . '(' . $safe_location . '-' . $branch_id . ')/students/' . $ad_no . '_' . $safe_student . '/';
                    
                    if (!is_dir($UPLOAD_DIR . $custom_folder)) mkdir($UPLOAD_DIR . $custom_folder, 0755, true);
                    
                    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                    $safe_name = $safe_student . '_' . $ad_no . '.' . $ext;
                    
                    if (move_uploaded_file($file['tmp_name'], $UPLOAD_DIR . $custom_folder . $safe_name)) {
                        $photo_path = $REAL_UPLOAD_REL . $custom_folder . $safe_name;
                        $studentModel->updatePhotoPath($ad_no, $branch_id, $photo_path);
                    }
                }
            }

            echo json_encode([
                'success' => true, 
                'message' => "Successfully Admitted!<br><strong>Adm-no: $formatted_ad_no</strong><br><strong> Student ID: $final_username</strong>"
            ]);
        }

    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action requested.']);
}
$conn->close();
?>