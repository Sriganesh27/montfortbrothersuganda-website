<?php
// controllers/AdminAppController.php

session_start();
header('Content-Type: application/json');

require_once '../config/config.php';
require_once '../models/AdminAppModel.php';

$branch_id = $_SESSION['branch_id'] ?? null;
if (!$branch_id) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access.']);
    exit;
}

global $DB_HOST, $DB_USER, $DB_PASS, $DB_NAME;
$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}

$adminAppModel = new AdminAppModel($conn);
$action = $_REQUEST['action'] ?? '';

try {
    if ($action === 'fetch_list') {
        $status = $_GET['status'] ?? 'All';
        $data = $adminAppModel->fetchList($branch_id, $status);
        echo json_encode(['success' => true, 'data' => $data]);
    } 
    elseif ($action === 'fetch_single') {
        $app_id = (int)($_GET['app_id'] ?? 0);
        $data = $adminAppModel->fetchSingle($branch_id, $app_id);
        if ($data) {
            echo json_encode(['success' => true, 'data' => $data]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Application not found.']);
        }
    } 
    elseif ($action === 'update_status') {
        $app_id = (int)($_POST['app_id'] ?? 0);
        $status = $_POST['status'] ?? '';
        if ($adminAppModel->updateStatus($branch_id, $app_id, $status)) {
            echo json_encode(['success' => true, 'message' => "Updated to $status"]);
        }
    } 
    elseif ($action === 'update_scholarship') {
        $app_id = (int)($_POST['app_id'] ?? 0);
        $scholarship = $_POST['scholarship'] ?? '';
        if ($adminAppModel->updateScholarship($branch_id, $app_id, $scholarship)) {
            echo json_encode(['success' => true, 'message' => "Scholarship updated."]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid action.']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server Error: ' . $e->getMessage()]);
}

$conn->close();
?>