<?php
// controllers/ApplicationController.php

session_start();
header('Content-Type: application/json');

require_once '../config/config.php';
require_once '../models/ApplicationModel.php';

global $DB_HOST, $DB_USER, $DB_PASS, $DB_NAME, $UPLOAD_DIR_BASE, $UPLOAD_FOLDER_REL;
$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}

$appModel = new ApplicationModel($conn);
$action = $_REQUEST['action'] ?? '';

if ($action === 'fetch_branches') {
    echo json_encode(['success' => true, 'data' => $appModel->getActiveBranches()]);
    exit;
}
elseif ($action === 'submit_application') {
    try {
        if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            throw new Exception("Security Error: Invalid submission token. Please refresh.");
        }

        $branch_id = (int)($_POST['branch_id'] ?? 0);
        $year = $_POST['admission_year'] ?? date('Y');
        list($class_code, $class_name) = array_pad(explode('|', $_POST['class_selection'] ?? ''), 2, '');
        $term = $_POST['term'] ?? 'Term 1';

        if (!$branch_id || !$class_code) throw new Exception("Please select a school branch and class.");

        $ref_number = $appModel->generateReferenceNumber($branch_id, $year);

        // --- File Upload Logic ---
        $upload_base = dirname(rtrim($UPLOAD_DIR_BASE, '/')) . '/';
        $rel_base = dirname(rtrim($UPLOAD_FOLDER_REL, '/')) . '/';
        $app_dir_rel = "applications/{$class_code}/{$ref_number}/";
        $app_dir_abs = $upload_base . $app_dir_rel;

        if (!is_dir($app_dir_abs)) mkdir($app_dir_abs, 0755, true);

        $photo_path = null;
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['png', 'jpg', 'jpeg'])) throw new Exception("Invalid photo format.");
            if ($_FILES['photo']['size'] > 204800) throw new Exception("Photo exceeds 200KB limit.");
            
            $dest = $app_dir_abs . $ref_number . '.' . $ext;
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $dest)) {
                $photo_path = $rel_base . $app_dir_rel . $ref_number . '.' . $ext;
            }
        }

        $prev_marks_path = null;
        if (isset($_FILES['prev_marks_doc']) && $_FILES['prev_marks_doc']['error'] === UPLOAD_ERR_OK) {
            $ext = strtolower(pathinfo($_FILES['prev_marks_doc']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['pdf', 'png', 'jpg', 'jpeg'])) throw new Exception("Invalid document format.");
            
            $dest = $app_dir_abs . $ref_number . '_marks.' . $ext;
            if (move_uploaded_file($_FILES['prev_marks_doc']['tmp_name'], $dest)) {
                $prev_marks_path = $rel_base . $app_dir_rel . $ref_number . '_marks.' . $ext;
            }
        }

        // --- Data Packaging ---
        $subjects = [];
        if (!empty($_POST['subject_name'])) {
            foreach ($_POST['subject_name'] as $i => $sname) {
                if (trim($sname)) {
                    $subjects[] = [
                        'subject' => trim($sname),
                        'mark' => trim($_POST['subject_mark'][$i] ?? ''),
                        'grade' => trim($_POST['subject_grade'][$i] ?? '')
                    ];
                }
            }
        }

        $appData = [
            'ref' => $ref_number, 'branch' => $branch_id, 'year' => $year, 'term' => $term, 'reg_date' => date('Y-m-d'),
            'name' => trim($_POST['name'] ?? ''), 'mname' => trim($_POST['mname'] ?? ''), 'surname' => trim($_POST['surname'] ?? ''),
            'gender' => $_POST['gender'] ?? '', 'dob' => $_POST['dob'] ?? null, 'nationality' => trim($_POST['nationality'] ?? 'Ugandan'),
            'postal' => $_POST['postal'] ?? null, 'house' => $_POST['house'] ?? null, 'street' => $_POST['street'] ?? null,
            'village' => $_POST['village'] ?? null, 'district' => $_POST['district'] ?? null, 'state' => $_POST['state'] ?? null, 'country' => 'Uganda',
            
            'f_name' => trim($_POST['f_name'] ?? ''), 'f_age' => $_POST['f_age'] ?: null, 'f_con' => $_POST['f_con'] ?? null, 'f_email' => $_POST['f_email'] ?? null, 'f_occ' => $_POST['f_occ'] ?? null, 'f_edu' => $_POST['f_edu'] ?? null,
            'm_name' => trim($_POST['m_name'] ?? ''), 'm_age' => $_POST['m_age'] ?: null, 'm_con' => $_POST['m_con'] ?? null, 'm_email' => $_POST['m_email'] ?? null, 'm_occ' => $_POST['m_occ'] ?? null, 'm_edu' => $_POST['m_edu'] ?? null,
            'g_name' => trim($_POST['g_name'] ?? null), 'g_rel' => trim($_POST['g_rel'] ?? null), 'g_age' => $_POST['g_age'] ?: null, 'g_con' => $_POST['g_con'] ?? null, 'g_email' => $_POST['g_email'] ?? null, 'g_occ' => $_POST['g_occ'] ?? null, 'g_edu' => $_POST['g_edu'] ?? null,
            
            'level' => $_POST['level'] ?? '', 'class_name' => $class_name, 'class_code' => $class_code, 
            'former_school' => trim($_POST['former_school'] ?? null), 'former_school_code' => trim($_POST['former_school_code'] ?? null), 'former_school_lin' => trim($_POST['former_school_lin'] ?? null), 
            'prev_marks_doc' => $prev_marks_path,
            'ple_score' => $_POST['ple_score'] ?: null, 'ple_ref' => $_POST['ple_ref'] ?: null, 'uce_score' => $_POST['uce_score'] ?: null, 'uce_ref' => $_POST['uce_ref'] ?: null,
            'subject_marks' => json_encode($subjects), 'more_info' => trim($_POST['more_info'] ?? null), 'photo_path' => $photo_path
        ];

        if ($appModel->saveApplication($appData)) {
            echo json_encode(['success' => true, 'ref' => $ref_number]);
        } else {
            throw new Exception("Database error saving application.");
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}
$conn->close();
?>