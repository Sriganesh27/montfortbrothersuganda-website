<?php
// erp/controllers/AuthController.php

session_start();
header('Content-Type: application/json');

require_once '../config/config.php';
require_once '../models/AuthModel.php';

// 1. Establish Database Connection
global $DB_HOST, $DB_USER, $DB_PASS, $DB_NAME;
$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}

$action = $_POST['action'] ?? '';
$authModel = new AuthModel($conn);

// 2. Route: Login Process
if ($action === 'login') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Please enter both username and password.']);
        exit;
    }

    try {
        // Fetch User
        $user = $authModel->getUserByUsername($username);

        if ($user && password_verify($password, $user['password'])) {
            
            // Check User Status
            if ($user['is_active'] != 1) {
                echo json_encode(['success' => false, 'message' => 'Your account is disabled. Contact administrator.']);
                exit;
            }

            // Super Admin Bypass
            if ($user['role'] === 'super_admin') {
                $_SESSION['user_id'] = $user['user_id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                
                $authModel->updateLastLogin($user['user_id']);
                echo json_encode(['success' => true, 'redirect' => 'super_admin']);
                exit;
            }

            // Standard Branch Admin/Staff Check
            $branch_id = $user['branch_id'];
            if (!$branch_id) {
                echo json_encode(['success' => false, 'message' => 'No branch assigned to your account.']);
                exit;
            }

            $branch = $authModel->getBranchDetails($branch_id);

            if (!$branch) {
                echo json_encode(['success' => false, 'message' => 'Assigned branch does not exist.']);
                exit;
            }

            if ($branch['status'] !== 'Active') {
                echo json_encode(['success' => false, 'message' => 'Your school branch is currently inactive.']);
                exit;
            }

            // Setup Secure Session
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['branch_id'] = $branch_id;
            $_SESSION['branch_name'] = $branch['branch_name'];

            $authModel->updateLastLogin($user['user_id']);

            echo json_encode(['success' => true, 'redirect' => 'admin']);
            
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid username or password.']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'An error occurred during authentication.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action requested.']);
}

$conn->close();
?>