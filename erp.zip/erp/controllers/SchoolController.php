<?php
// controllers/SchoolController.php
session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../models/SchoolModel.php';

// Security: Super Admin Access Only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Super User') {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$model = new SchoolModel($conn);
$action = $_REQUEST['action'] ?? '';

switch ($action) {
    case 'list':
        echo json_encode($model->getAllBranches());
        break;

    case 'save':
        $success = $model->saveBranch($_POST['branch_id'] ?? null, $_POST['branch_name'], $_POST['branch_location'], $_POST['branch_type']);
        echo json_encode(['status' => $success ? 'success' : 'error']);
        break;

    case 'delete':
        $id = (int)$_POST['branch_id'];
        if ($model->getStudentCount($id) > 0) {
            echo json_encode(['status' => 'error', 'message' => 'Cannot delete: Branch has active students.']);
        } else {
            $model->deleteBranch($id);
            echo json_encode(['status' => 'success']);
        }
        break;
}