<?php
// controllers/SuperAdminController.php

session_start();
header('Content-Type: application/json');

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../models/SuperAdminModel.php';

// Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Super User') {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$model = new SuperAdminModel($conn);
$action = $_REQUEST['action'] ?? '';

try {
    switch ($action) {
        case 'list_branches':
            echo json_encode($model->getAllBranches());
            break;

        case 'save_branch':
            $success = $model->saveBranch($_POST['branch_id'] ?? null, $_POST['branch_name'], $_POST['branch_location'], $_POST['branch_type']);
            echo json_encode(['status' => $success ? 'success' : 'error']);
            break;

        case 'delete_branch':
            $id = (int)$_POST['branch_id'];
            if ($model->countStudentsInBranch($id) > 0) {
                echo json_encode(['status' => 'error', 'message' => 'Cannot delete: Students exist in branch.']);
            } else {
                $model->deleteBranch($id);
                echo json_encode(['status' => 'success']);
            }
            break;

        default:
            echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}